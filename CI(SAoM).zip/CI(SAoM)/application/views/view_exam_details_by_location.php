<!DOCTYPE html>
<html>
<head>
        <link rel="stylesheet" href="../../assets/Styles/style.css">
    <title>Maintenace Request Form</title>
</head>
    
    <style>
        input[type =text]
        {
            width: 100%;
            padding: 20px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            
   
        }
        
        #form
        {
            border-radius: 20px;
            padding: 1%;
            width: 800px;
            height: 600px;
            position: relative;
          padding-bottom: 100px;
            left: 600px;
            background-color: #34495e;
            margin-bottom: 50px;
            margin-top: 50px;
        }
    
        
        #submit
        {
             position: absolute;
             top: 500px;
             right: 370px;
             height: 50px;
             width: 90px;
            border-radius: 20px;
            background-color: #39ca74;
        }
        
        .maintenance-header h1
        {
            font-family: arial;
             background-color: white;
        }
        
     
    </style>
<body>
        <div id="container">
            <header>
                <div class="header">
    
                    <div class="inner_header">

                        <div class="logo_container">
                            <h1>Sullimar<span>Acadamy</span></h1>
                        </div>
                   </div>

                    <ul class="navigation">
                       <li><a href ="<?php echo site_url('SAoM/index'); ?>">Home</a></li>
                       <li><a href ="#">About</a></li>
                       <li><a href ="#">Classes</a></li>
                       <li><a href ="#">Instruments</a></li>
                       <li><a href ="#">Contact Us</a></li>

                    </ul>

                </div>
 
            </header>
            
<div id="form">
<h1 class ="maintenance-header">View Exam Details</h1>
    
    <input type="text" id="Exam Name" placeholder="Exam Name">
     <input type="text" id="Exam_ID" placeholder="Exam ID">
     <input type="text" id="Exam-Location" placeholder="Exam Location">
     <input type="text" id="Building-Number" placeholder="Building Number">
     <input type="text" id="Room-Number" placeholder="Room Number">
    
    
    <input type="submit" value="Search" id="submit">
            
   </div> 
            
 <footer>
                <div class="footer_row">
                    <div class="column">
                        <h3>About</h3>
                        <p>A lot of text about the Sullimar Academy of Music telling the user what it is and what they can sign up for.</p>
                    </div>
                    <div class="column">
                        <h3>Music</h3>
                        <p>1 to 1 Tuition</p>
                        <p>Courses</p>
                    </div>
                    <div class="column">
                        <h3>Contact</h3>
                        <p>Email: contact@saom.ie</p>
                        <p>Phone: 061-123456</p>
                    </div>
                </div>
            </footer>
            
</body>
</html>
