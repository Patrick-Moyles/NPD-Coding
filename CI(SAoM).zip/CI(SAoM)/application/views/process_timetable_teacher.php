<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Admin - SAoM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../../assets/Styles/style.css">
    </head>
    <body>
        <div id="container">
            <header>
                <div class="header">
    
                    <div class="inner_header">

                        <div class="logo_container">
                            <a href="<?php echo site_url('SAoM/index'); ?>"><h1>Sullimar<span>Acadamy</span></h1></a>
                        </div>
                   </div>

                    <ul class="navigation">
                       <li><a href ="<?php echo site_url('SAoM/index'); ?>">Home</a></li>
                       <li><a href ="book_course.html">Courses</a></li>
                       <li><a href ="book_lesson.html">Lessons</a></li>
                       <li><a href ="book_exam.html">Exams</a></li>
                       <li><a href ="#">Books</a></li>
                       <li><a href ="#">About</a></li>
                       <li><a href ="#">Login</a></li>
                    </ul>

                </div>
            </header>
            <main>
                <div class="form_title">
                    <h1>Process Timetable</h1>
                </div>
                <div class="form_border">
                    <form action="" method="POST" class="form" id="process_timetable">
                        <h2>Teacher</h2>
                        <select class="select_teacher" name="teacher">
                            <option disabled="disabled" selected="selected">Choose Teacher</option>
                            <option>Teacher 1</option>
                            <option>Teacher 2</option>
                            <option>Teacher 3</option>
                            <option>Teacher 4</option>
                        </select>
                        
                        <h2>Subject</h2>
                        <select class="select_subject" name="subject">
                            <option disabled="disabled" selected="selected">Choose Subject/Module</option>
                            <option>Module 1</option>
                            <option>Module 2</option>
                            <option>Module 3</option>
                            <option>Module 4</option>
                        </select>
                        
                        <h2>Room</h2>
                        <input type="text" class="inputs" name="room">
                        
                        <h2>Start Time</h2>
                        <input type="text" class="inputs" name="teacher_start_time">
                        
                        <h2>End Time</h2>
                        <input type="text" class="inputs" name="teacher_end_time">
                        
                        <h2>Day</h2>
                        <input type="text" class="inputs" name="teacher_day">
                        
                        <input  type="submit" class="process_timetable_button" value="Process Timetable">
                        <a href="index.html"><input  type="button" class="cancel_button teacher_timetable" value="Cancel"></a>
                    </form>
                </div>
            </main>
            <footer>
                <div class="footer_row">
                    <div class="column">
                        <h3>Admin</h3>
                        <a href="#"><p>Admin Dashboard</p></a>
                    </div>
                    <div class="column">
                        <h3>Music</h3>
                        <a href="book_course.html"><p>Courses</p></a>
                        <a href="book_lesson.html"><p>Lessons</p></a>
                    </div>
                    <div class="column">
                        <h3>Contact</h3>
                        <p>Email: contact@saom.ie</p>
                        <p>Phone: 061-123456</p>
                    </div>
                </div>
            </footer>
        </div>
    </body>
</html>
