<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>SAoM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../../assets/Styles/style.css">
    </head>
    <body>
        <div id="container">
            <header>
                <div class="header">
    
                    <div class="inner_header">

                        <div class="logo_container">
                            <a href="<?php echo site_url('SAoM/index'); ?>"><h1>Sullimar<span>Acadamy</span></h1></a>
                        </div>
                   </div>

                    <ul class="navigation">
                        <li><a href ="<?php echo site_url('SAoM/index'); ?>">Home</a></li>
                       <li><a href ="book_course.html">Courses</a></li>
                       <li><a href ="book_lesson.html">Lessons</a></li>
                       <li><a href ="book_exam.html">Exams</a></li>
                       <li><a href ="#">Books</a></li>
                       <li><a href ="#">About</a></li>
                       <li><a href ="#">Login</a></li>
                    </ul>

                </div>
            </header>
            <main>
                <div class="top_banner">
                    <div class="top_title"> 
                        <h1>Welcome to the Sullimar Academy of Music</h1>
                    </div>
                    <img src="../../assets/Images/home_top_banner.jpg">
                </div>
                <div class="banner_row">
                    <div class="column">
                        <a href="book_course.html"><div>
                        <img src="../../assets/Images/banner_row_course.png">
                        <h2>Courses</h2>
                        <p>Thinking of starting a music course? We have a wide range of courses to offer including a Leaving Cert Music course</p>
                        </div></a>
                    </div>
                    <div class="column">
                        <a href="book_lesson.html"><div>
                        <img src="../../assets/Images/banner_row_lesson.png">
                        <h2>Lessons</h2>
                        <p>Would you like to learn an instrument? We have the best music teachers in the country here to help you become a prodigy </p>
                        </div></a>
                    </div>
                    <div class="column">
                        <a href="#"><div>
                        <img src="../../assets/Images/banner_row_book.png">
                        <h2>Books</h2>
                        <p>We have plenty of music related books for sale, from music theory to books on specific instruments</p>
                        </div></a>
                    </div>
                </div>
                
                <div class="main_row">
                    <div class="column">
                        <h2>SAoM</h2>
                        <p>The Sullimar Academy of Music is situated on the Dublin Road in Limerick.  SAOM was established in 1980 as a small school of music with 2 teachers and over 30 pupils.  Over the past 40 years, the school has grown significantly and has expanded the range of instruments taught at the school as well as now offering courses for Leaving Cert and diploma/degree level programs. </p>
                        <p>You can register an account on the website to book courses, book lessons and book exams. You can also register if you're a parent and book lessons and exams for your children. We sell many types of music related books.</p>
                    </div>
                    <div class="column">
                        <img src="../../assets/Images/home_main_right.jpeg">
                    </div>
                </div>
                
                <div class="bottom_div">
                    <h2>We have many courses to check out</h2>
                    <p>We can help out with your dream of becoming a musician</p>
                    <input type="button" value="Register">
                </div>
                
            </main>
            <footer>
                <div class="footer_row">
                    <div class="column">
                        <h3>Admin</h3>
                        <a href="<?php echo site_url('SAoM/admin'); ?>"><p>Admin Dashboard</p></a>
                    </div>
                    <div class="column">
                        <h3>Music</h3>
                        <a href="book_course.html"><p>Courses</p></a>
                        <a href="book_lesson.html"><p>Lessons</p></a>
                    </div>
                    <div class="column">
                        <h3>Contact</h3>
                        <p>Email: contact@saom.ie</p>
                        <p>Phone: 061-123456</p>
                    </div>
                </div>
            </footer>
        </div>
    </body>
</html>
