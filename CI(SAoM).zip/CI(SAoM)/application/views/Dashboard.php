<!DOCTYPE html>
<html>
<head>
    
    <title>Admin Dashboard</title>
</head>
    <style>
    *
{
    padding: 0;
    margin: 0;
   
    
}

.header
{
   width: 100%;
   height: 120px;
   background-color: black;
   color: white;
}

#image
 {
    height: 120px;
     
     background-color: white;
     border-radius: 50px;
     
 }
        
.main-content
{
     display: flex;
}
    
.sidebar
{
    flex: 1;
   height: 900px;
background-color: #2c3e50;
}
        
.content
 {
    height: 805px;
    background-color: #34495e;
    font-size: 20px;
    font-weight: bold;
     flex: 3;
     
 }
        
 ul li
{
    padding: 20px;
    border-bottom: 2px solid grey;
    list-style-type: none;
}
        
.content
{
      text-align: center;   
      padding-top: 5%;
}

h2
{
     padding-top: 5%;        
}
        
h4
{
     padding-top: 5%;       
}
        
li
{
     color: white;
 }
      
    </style>
<body>


    
 
    <div class="header">
        <center><img src="../../assets/Images/admin.png" id="image"></center>
    </div>
    
        <div class="main-content">
        
            <div class="sidebar">
            <ul>
        
            <li>Add Student</li>
            <li>Add Teacher</li>
            <li>Update Student</li>
            <li>Update Teacher</li>
            <li>Delete Student</li>
            <li>Delete Teacher</li>
            <li>Add Book</li>
            <li>Delete Book</li>
            <li>Update Book</li>
            <a href="<?php echo site_url('SAoM/index'); ?>"><li>Logout</li></a>
        </ul>
            </div>
            
            <div class="content">
            
            <h2> Hello Admin: Patrick Moyles</h2>
                
                <h3>Date Since Last Login: 19/11/2020</h3>
                
                <h4>No Further Changes have been maid since last login</h4>
            </div>
        </div>
    
   
   
</body>
</html>
