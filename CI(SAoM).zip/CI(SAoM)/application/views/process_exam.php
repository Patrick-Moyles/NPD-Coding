<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Admin - SAoM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../../assets/Styles/style.css">
    </head>
    <body>
        <div id="container">
            <header>
                <div class="header">
    
                    <div class="inner_header">

                        <div class="logo_container">
                            <a href="<?php echo site_url('SAoM/index'); ?>"><h1>Sullimar<span>Acadamy</span></h1></a>
                        </div>
                   </div>

                    <ul class="navigation">
                       <li><a href ="<?php echo site_url('SAoM/index'); ?>">Home</a></li>
                       <li><a href ="book_course.html">Courses</a></li>
                       <li><a href ="book_lesson.html">Lessons</a></li>
                       <li><a href ="book_exam.html">Exams</a></li>
                       <li><a href ="#">Books</a></li>
                       <li><a href ="#">About</a></li>
                       <li><a href ="#">Login</a></li>
                    </ul>

                </div>
            </header>
            <main>
                <div class="form_title">
                    <h1>Process Exam</h1>
                </div>
                <div class="form_border">
                    <form action="" method="POST" class="form" id="process_exam">
                        <h2>Subject</h2>
                        <select class="select_exam_subject" name="subject">
                            <option disabled="disabled" selected="selected">Choose Instrument/Subject</option>
                            <option>Instrument 1</option>
                            <option>Instrument 2</option>
                            <option>Instrument 3</option>
                            <option>Instrument 4</option>
                        </select>
                        <select class="select_grade" name="grade">
                            <option disabled="disabled" selected="selected">Choose Grade</option>
                            <option>Grade 1</option>
                            <option>Grade 2</option>
                            <option>Grade 3</option>
                            <option>Grade 4</option>
                        </select>
                        
                        <h2>Start Time</h2>
                        <input type="text" class="inputs" name="exam_start_time">
                        
                        <h2>End Time</h2>
                        <input type="text" class="inputs" name="exam_end_time">
                        
                        <h2>Date</h2>
                        <input type="text" class="inputs" name="exam_date">
                        
                        <h2>Price</h2>
                        <input type="text" class="inputs" name="exam_price">
                        
                        <h2>Exam Centre</h2>
                        <select class="select_exam_centre" name="exam_centre">
                            <option disabled="disabled" selected="selected">Choose Exam Centre</option>
                            <option>Exam Centre 1</option>
                            <option>Exam Centre 2</option>
                            <option>Exam Centre 3</option>
                            <option>Exam Centre 4</option>
                        </select>
                        
                        <h2>Examiner</h2>
                        <select class="select_examiner" name="examiner">
                            <option disabled="disabled" selected="selected">Choose Examiner</option>
                            <option>Examiner 1</option>
                            <option>Examiner 2</option>
                            <option>Examiner 3</option>
                            <option>Examiner 4</option>
                        </select>
                        
                        <input  type="submit" class="process_exam_button" value="Process Exam">
                        <a href="index.html"><input  type="button" class="cancel_button" value="Cancel"></a>
                    </form>
                </div>
            </main>
            <footer>
                <div class="footer_row">
                    <div class="column">
                        <h3>Admin</h3>
                        <a href="#"><p>Admin Dashboard</p></a>
                    </div>
                    <div class="column">
                        <h3>Music</h3>
                        <a href="book_course.html"><p>Courses</p></a>
                        <a href="book_lesson.html"><p>Lessons</p></a>
                    </div>
                    <div class="column">
                        <h3>Contact</h3>
                        <p>Email: contact@saom.ie</p>
                        <p>Phone: 061-123456</p>
                    </div>
                </div>
            </footer>
        </div>
    </body>
</html>
