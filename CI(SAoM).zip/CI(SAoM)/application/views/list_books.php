<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Admin - SAoM</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../../assets/Styles/style.css">
    </head>
    <body>
        <div id="container">
            <header>
                <div class="header">
    
                    <div class="inner_header">

                        <div class="logo_container">
                            <a href="<?php echo site_url('SAoM/index'); ?>"><h1>Sullimar<span>Acadamy</span></h1></a>
                        </div>
                   </div>

                    <ul class="navigation">
                        <li><a href ="<?php echo site_url('SAoM/index'); ?>">Home</a></li>
                       <li><a href ="book_course.html">Courses</a></li>
                       <li><a href ="book_lesson.html">Lessons</a></li>
                       <li><a href ="book_exam.html">Exams</a></li>
                       <li><a href ="#">Books</a></li>
                       <li><a href ="#">About</a></li>
                       <li><a href ="#">Login</a></li>
                    </ul>

                </div>
            </header>
            <main>
                <div class="book_list">
                    <div class="book_list_title">
                        <h2>Books</h2>
                    </div>
                    <div class="book_list_items">
                        <div class="book_item">
                            <div class="book_id">
                                <p>1</p>
                            </div>
                            <div class="book_content">
                                <p>Book Title</p>
                                <input type="button" id="update_book" value="Update">
                                <input type="button" id="delete_book" value="Delete">
                            </div>
                        </div>
                        
                        <div class="book_item">
                            <div class="book_id">
                                <p>2</p>
                            </div>
                            <div class="book_content">
                                <p>Book Title</p>
                                <input type="button" id="update_book" value="Update">
                                <input type="button" id="delete_book" value="Delete">
                            </div>
                        </div>
                        
                        <div class="book_item">
                            <div class="book_id">
                                <p>3</p>
                            </div>
                            <div class="book_content">
                                <p>Book Title</p>
                                <input type="button" id="update_book" value="Update">
                                <input type="button" id="delete_book" value="Delete">
                            </div>
                        </div>
                        
                        <div class="book_item">
                            <div class="book_id">
                                <p>4</p>
                            </div>
                            <div class="book_content">
                                <p>Book Title</p>
                                <input type="button" id="update_book" value="Update">
                                <input type="button" id="delete_book" value="Delete">
                            </div>
                        </div>
                        
                        <div class="book_item">
                            <div class="book_id">
                                <p>5</p>
                            </div>
                            <div class="book_content">
                                <p>Book Title</p>
                                <input type="button" id="update_book" value="Update">
                                <input type="button" id="delete_book" value="Delete">
                            </div>
                        </div>
                        
                        <div class="book_item">
                            <div class="book_id">
                                <p>6</p>
                            </div>
                            <div class="book_content">
                                <p>Book Title</p>
                                <input type="button" id="update_book" value="Update">
                                <input type="button" id="delete_book" value="Delete">
                            </div>
                        </div>
                        
                    </div>
                </div>
            </main>
            <footer>
                <div class="footer_row">
                    <div class="column">
                        <h3>Admin</h3>
                        <a href="#"><p>Admin Dashboard</p></a>
                    </div>
                    <div class="column">
                        <h3>Music</h3>
                        <a href="book_course.html"><p>Courses</p></a>
                        <a href="book_lesson.html"><p>Lessons</p></a>
                    </div>
                    <div class="column">
                        <h3>Contact</h3>
                        <p>Email: contact@saom.ie</p>
                        <p>Phone: 061-123456</p>
                    </div>
                </div>
            </footer>
        </div>
    </body>
</html>
