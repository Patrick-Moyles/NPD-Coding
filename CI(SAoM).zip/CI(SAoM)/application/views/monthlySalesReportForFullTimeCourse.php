<!DOCTYPE html>
<html>
<head>
        <link rel="stylesheet" href="../../assets/Styles/style.css">
    <title>Maintenace Request Form</title>
</head>
    
    <style>
        
        *
        {
            margin: 0;
            padding: 0;
            outline: 0;
        }

       .filter
        {
            position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                z-index: 1;
                opacity: .7;
        }
        
        body
        {
            background-color: #2c3e50;
        }
        
        table
        {
           position: absolute;
            z-index: 2;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            width: 60%;
            border-collapse: collapse;
            border-spacing: 0;
            border-radius: 12px 12px 0 0;
            box-shadow: 0 5px 12px rgba(32,32,32,3);
            height: 400px;
            background-color: beige;
            text-align: center;
        }
        
        th
        {
            background-color: #34495e;
            text-transform: uppercase;
            color: white;
        }
        
        th,td
        {
            padding: 12px 15px;
            font-family: sans-serif;
        }
       
    </style>
<body>
        <div id="container">
            <header>
                <div class="header">
    
                    <div class="inner_header">

                        <div class="logo_container">
                            <h1>Sullimar<span>Acadamy</span></h1>
                        </div>
                   </div>

                    <ul class="navigation">
                       <li><a href ="<?php echo site_url('SAoM/index'); ?>">Home</a></li>
                       <li><a href ="#">About</a></li>
                       <li><a href ="#">Classes</a></li>
                       <li><a href ="#">Instruments</a></li>
                       <li><a href ="#">Contact Us</a></li>

                    </ul>
                    
                    

                </div>
  
            </header>
            
       <div class="filter">
        <table>
        <tr>
            <th>Course Name</th>
            <th>Course ID</th>
           <th>Total Money Gained From Course</th>
           <th>Expenses</th>
           <th>Profit</th>
        </tr>  
            
        <tr>
            <td>Internet Systems Development</td>
            <td>3</td>
            <td>40,000</td>
            <td>20,000</td>
            <td>20,000</td>
        </tr>
            <tr>
            <td>Internet Systems Development</td>
            <td>3</td>
            <td>40,000</td>
            <td>20,000</td>
            <td>20,000</td>
        </tr>
           <td>Internet Systems Development</td>
            <td>3</td>
            <td>40,000</td>
            <td>20,000</td>
            <td>20,000</td>
     
        <tr>
            <td>Internet Systems Development</td>
            <td>3</td>
            <td>40,000</td>
            <td>20,000</td>
            <td>20,000</td>
        </tr>
            <td>Internet Systems Development</td>
            <td>3</td>
            <td>40,000</td>
            <td>20,000</td>
            <td>20,000</td>
        <tr>
           <td>Internet Systems Development</td>
            <td>3</td>
            <td>40,000</td>
            <td>20,000</td>
            <td>20,000</td>
        </tr>
        </table>
           
        </div>    
            
         
    </div>        
            
     
            <footer>
                <div class="footer_row">
                    <div class="column">
                        <h3>About</h3>
                        <p>A lot of text about the Sullimar Academy of Music telling the user what it is and what they can sign up for.</p>
                    </div>
                    <div class="column">
                        <h3>Music</h3>
                        <p>1 to 1 Tuition</p>
                        <p>Courses</p>
                    </div>
                    <div class="column">
                        <h3>Contact</h3>
                        <p>Email: contact@saom.ie</p>
                        <p>Phone: 061-123456</p>
                    </div>
                </div>
            </footer>
            
 
             
</body>
</html>
