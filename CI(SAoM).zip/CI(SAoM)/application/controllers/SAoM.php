<?php

class SAoM extends CI_Controller {
 
    function __construct() {
        parent::__construct();
		
		
                
    }
	
	
    function index() {
        
        
        $this->load->view('home');
    }
    
    function admin(){
        $this->load->view('Dashboard');
    }
    
    
}